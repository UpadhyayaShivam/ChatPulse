const express = require('express');
const userController = require('../controller/userController');

const chatRouter = express.Router();


// chatRouter.get('/', userController.helloRoute);

// chatRouter.post('/register/', userController.registerUser);


module.exports = chatRouter;


